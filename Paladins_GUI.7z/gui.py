#!/bin/env python

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon
#from PyQt5.QtCore import QThread
from flow import FlowLayout
import requests
from datetime import datetime
import json
from hashlib import md5
import time
import os

devid = "2518"
authkey = "BF4E10BFD82145C89BFB4340F26754EA"


def timeformat(buh):
	i = datetime.strptime(buh, '%m/%d/%Y %I:%M:%S %p')
	i = i + (datetime.now() - datetime.utcnow())
	i= i.strftime('%d/%m/%Y %I:%M:%S %p')
	return i

def timestamp():
	timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
	return timestamp


def signature(method):
	signature = devid + method + authkey + timestamp()
	signature = md5(signature.encode('utf-8')).hexdigest()
	return signature

def createsession():
	with open("sessions.json") as sessions_file:
		sessions = json.load(sessions_file)
	if (time.time() - sessions["epoch"]) < 900:
		session_id = sessions["session_id"]
	else:
		request = requests.get('http://api.paladins.com/paladinsapi.svc/createsessionJson' + '/' + devid + '/' + signature("createsession") + '/' + timestamp())
		request = json.loads(request.text)
		session_id = request["session_id"]
	data = {"session_id": session_id, "epoch": time.time()}
	with open("sessions.json", "w") as sessions_file:
		sessions_file.write(json.dumps(data, indent=4, sort_keys=True, separators=(',', ': ')))
	return session_id


def getplayer(print_data, player):
	playerinfo = requests.get("http://api.paladins.com/paladinsapi.svc/getplayerJson/" + devid + '/' + signature("getplayer") + '/' + createsession() + '/' + timestamp() + '/' + player)
	playerinfo_json = json.loads(playerinfo.text)[0]
	if print_data == 1:
		print("Level:", playerinfo_json["Level"])
		print("Wins:", playerinfo_json["Wins"])
		print("Losses:", playerinfo_json["Losses"])
		print("Region:", playerinfo_json["Region"])
		print("Creation date:", timeformat(playerinfo_json["Created_Datetime"]))
		print("Last login:", timeformat(playerinfo_json["Last_Login_Datetime"]))
	return playerinfo_json


def getfriends(player):
	getfriends = requests.get("http://api.paladins.com/paladinsapi.svc/getfriendsJson/" + devid + '/' + signature("getfriends") + '/' + createsession() + '/' + timestamp() + '/' + player)
	getfriends = json.loads(getfriends.text)
	friends = [friend["name"] for friend in getfriends]
	return friends

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class App(QMainWindow):

	def __init__(self):
		super().__init__()

		self.initUI()

	def initUI(self):
		self.setGeometry(300, 300, 350, 100)
		self.setFixedSize(350, 70)
		self.setWindowTitle("Paladins_Test")

		self.hbox = QHBoxLayout()
		self.vbox = QVBoxLayout()
		self.vbox.addLayout(self.hbox)

		window = QWidget()
		window.setObjectName("mainwidget")
		window.setLayout(self.vbox)
		self.setCentralWidget(window)

		self.textbox = QLineEdit(self)
		self.button = QPushButton("Submit", self)

		self.button.clicked.connect(self.showTabs)
		self.textbox.returnPressed.connect(self.button.click)

		self.hbox.addWidget(self.textbox)
		self.hbox.addWidget(self.button)

	def showTabs(self):
		self.setFixedSize(350, 550)
		self.player = self.textbox.text()
		self.tabwidget = QTabWidget(self)

		self.vbox.addWidget(self.tabwidget)

		self.playerinfo_tab()
		self.friends_tab()

	def playerinfo_tab(self):
		tab1 = QWidget(self)
		tab1.layout = QVBoxLayout()

		tab1.setLayout(tab1.layout)
		self.tabwidget.addTab(tab1, "Player Info")

		playerinfo = getplayer(0, self.player)

		label1 = QLabel(self)
		label1.setText(str(playerinfo["Name"]))
		label1.setObjectName("playername")

		tab1.layout.addWidget(label1)

		self.addlabel(tab1.layout, "Level", playerinfo["Level"])

		self.addlabel(tab1.layout, "Wins", playerinfo["Wins"])

		self.addlabel(tab1.layout, "Losses", playerinfo["Losses"])

		self.addlabel(tab1.layout, "Region", playerinfo["Region"])

		self.addlabel(tab1.layout, "Creation date:", timeformat(playerinfo["Created_Datetime"]))

		self.addlabel(tab1.layout, "Last login:", timeformat(playerinfo["Last_Login_Datetime"]))

		tab1.layout.addStretch(1)

	def addlabel(self, layout, string, value):
		box = QWidget()
		box.layout = QVBoxLayout()
		box.setLayout(box.layout)

		label_string = QLabel(self)
		label_string.setText(string)

		label_value = QLabel(self)
		label_value.setText(str(value))

		box.layout.addWidget(label_string)
		box.layout.addWidget(label_value)

		layout.addWidget(box)


	def friends_tab(self):
		tab2 = QWidget()
		tab2.layout = FlowLayout()

		tab2.setLayout(tab2.layout)

		scrollbox = QWidget(self)
		scrollbox.layout = QVBoxLayout()
		scrollbox.setLayout(scrollbox.layout)
		scroll = QScrollArea(self)
		scroll.setWidgetResizable(True)
		scrollbox.layout.addWidget(scroll)
		scroll.setWidget(tab2)

		self.tabwidget.addTab(scrollbox, "Friends")

		friends = getfriends(self.player)

		for i in friends:
			friend_status = requests.get("http://api.paladins.com/paladinsapi.svc/getplayerstatusJson/" + devid + '/' + signature("getplayerstatus") + '/' + createsession() + '/' + timestamp() + '/' + i)
			friend_status = json.loads(friend_status.text)[0]
			friendbox = QWidget()
			friendbox.layout = QVBoxLayout()
			friendname = QLabel()
			friendname.setText(i)
			friendstatus = QLabel()
			friendstatus.setText(friend_status["status_string"])
			friendbox.layout.addWidget(friendname)
			friendbox.layout.addWidget(friendstatus)
			friendbox.setLayout(friendbox.layout)
			friendbox.setObjectName("friendbox")
			tab2.layout.addWidget(friendbox)

if __name__ == '__main__':
	app = QApplication(sys.argv)
	gui = App()

	with open(resource_path('style.qss'), 'r') as myfile:
		qss = myfile.read()

	app.setWindowIcon(QIcon(resource_path('icon.ico')))
	app.setStyleSheet(qss)
	gui.show()
	sys.exit(app.exec_())
